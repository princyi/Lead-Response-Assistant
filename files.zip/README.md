# Customer Enquiry Assistant - Setup & Usage Guide

## Quick Start

### Prerequisites
- Node.js 16+ (if running locally)
- Modern web browser (Chrome, Firefox, Safari, Edge)
- No API key needed (system uses authenticated Claude API)

### Option 1: Run as React Component
1. Copy `enquiry_assistant.jsx` into your React project
2. Install dependencies (if needed): `npm install lucide-react`
3. Import and use:
```jsx
import EnquiryAssistant from './enquiry_assistant';

export default function App() {
  return <EnquiryAssistant />;
}
```

### Option 2: Deploy as Artifact
- Paste `enquiry_assistant.jsx` into Claude.ai
- System renders interactive component in browser
- No installation required
- Full functionality in browser

---

## Example Workflows

### Example 1: Technical Troubleshooting
**Input:**
```
Hi, I am getting damp patches on my bedroom wall after rains. What should I do?
```

**Generated Response Components:**

**Acknowledgment:**
```
I understand this is concerning, especially in a bedroom where you want comfort 
and safety. Damp patches after rain can have several causes, so let's gather 
more information before recommending action.
```

**Clarifying Questions:**
- How long have you noticed the damp patches, and are they growing or stable?
- Are they on the wall itself, in corners, or along the ceiling area?
- Is there any visible mold, discoloration, or musty smell?

**Next Steps:**
1. Monitor the patch over the next 48 hours with good ventilation
2. Check for external issues (gutter damage, roof leak, poor grading)
3. If the problem persists, consult a surveyor or damp specialist
4. Consider moisture control (dehumidifier, improved ventilation)

**Warnings:**
- Do not assume it's only condensation without professional assessment
- Structural damage may require urgent intervention
- Black mold requires professional remediation (health risk)

**Confidence:** 72% (domain requires professional expertise)

---

### Example 2: Order Status
**Input:**
```
I ordered something 2 weeks ago and haven't received it yet. Where is it?
```

**Generated Response Components:**

**Acknowledgment:**
```
I'm sorry your package hasn't arrived yet—I understand the frustration with 
the wait. Let's get this sorted out for you.
```

**Clarifying Questions:**
- Do you have an order confirmation number or tracking reference?
- Which shipping method did you select at checkout?
- What was the estimated delivery date provided?

**Next Steps:**
1. Check your email for tracking information
2. Log into your account to verify order status
3. If no tracking info available, contact our support team with order number
4. Carriers may experience delays; if past promised date, we can investigate

**Warnings:**
- Some shipping methods lack real-time tracking
- International orders may face customs delays
- We're happy to follow up on your behalf

**Confidence:** 88% (clear domain, standard process)

---

### Example 3: Complaint/Escalation
**Input:**
```
The product I received is completely broken. This is the second time. I'm very upset.
```

**Generated Response Components:**

**Acknowledgment:**
```
I'm truly sorry to hear this happened again. That's unacceptable, and I 
understand your frustration completely. Let's make this right.
```

**Analysis:**
- Intent: Request replacement + apology
- Severity: HIGH (repeat failure + emotional distress)
- Confidence: 95% (clear complaint)

**Clarifying Questions:**
- Can you briefly describe what's broken or not working?
- Do you have photos of the damage?
- Would you prefer a replacement, refund, or alternative solution?

**Next Steps:**
1. I'm flagging this as a repeat issue for priority review
2. Our manager will contact you within 24 hours
3. We'll offer replacement with expedited shipping (free)
4. We'll also investigate the manufacturing issue

**Warnings:**
- This case requires managerial approval for replacement/refund
- You may be asked to return the broken unit (prepaid shipping)

**Confidence:** 95%

---

## System Behavior Details

### Confidence Scoring

**High (≥ 0.8)**
- Clear, common issues
- Standard processes
- Low risk of hallucination
- Minimal review needed

**Medium (0.6-0.8)**
- Some domain expertise required
- Partially clear information
- Some assumptions made
- Moderate review recommended

**Low (< 0.6)**
- Highly specialized domain
- Missing critical context
- High hallucination risk
- Extensive review required

### Severity Levels

**LOW**
- Informational questions
- Non-urgent requests
- No immediate action needed
- Example: "How do I check my account balance?"

**MEDIUM**
- Standard issues with some urgency
- Straightforward troubleshooting
- Normal escalation path
- Example: "My order hasn't arrived"

**HIGH**
- Customer safety/satisfaction at risk
- Repeat issues
- Emotional distress evident
- Financial impact
- Example: "Product is broken again", "Account compromised"

---

## How Accuracy is Ensured

### 1. Prompt-Level Safeguards
The system prompt explicitly includes:
```
CRITICAL GUIDELINES:
1. NEVER make claims you cannot verify. If unsure, acknowledge uncertainty explicitly.
2. Ask 2-3 clarifying follow-up questions to better understand the issue.
3. Provide safe, practical next steps (not false promises).
4. Acknowledge the customer's concern with empathy.
```

### 2. Structured Output Format
Enforces thinking in sections:
- **Acknowledgment** (empathy first)
- **Analysis** (facts and intent)
- **Clarifying Questions** (gather missing info)
- **Next Steps** (safe, practical actions)
- **Warnings** (limitations and disclaimers)

### 3. Confidence Scoring
Model self-assesses reliability:
- Low confidence → Trigger extended review
- High confidence → Allow faster approval
- Prevents false certainty

### 4. Warnings Section
Mandatory disclaimers catch edge cases:
- "Requires professional inspection"
- "Company policy limits..."
- "We recommend verifying..."

### 5. Human Review
Responses never sent without approval:
- All responses reviewed before sending
- Confidence score guides review intensity
- Warnings highlighted for attention
- Raw JSON visible for auditing

---

## Common Patterns Observed

### System Excels At:
✅ Acknowledgment and empathy
✅ Asking good clarifying questions
✅ Identifying information gaps
✅ Recommending safe next steps
✅ Including relevant disclaimers
✅ Routing to specialists when needed

### System Requires Review For:
⚠️ Product-specific details (may hallucinate features)
⚠️ Pricing/availability (needs current data)
⚠️ Company policies (needs accurate reference)
⚠️ Legal matters (needs lawyer review)
⚠️ Technical specifications (verify before sending)

### System Handles Well:
✅ Damp/moisture issues (asks diagnostic questions)
✅ Shipping/tracking (suggests checking order status)
✅ Complaints (routes to manager, offers solutions)
✅ Account access (gathers details, suggests verification)
✅ Product malfunction (asks "what's broken exactly?")

---

## Integration Examples

### With Zendesk
```javascript
// Zendesk ticket created
const enquiry = ticket.description;

// Call assistant
const response = await generateResponse(enquiry);

// Display in agent interface
ticket.suggestedResponse = response.acknowledgment + "\n\n" + response.nextSteps;
ticket.confidence = response.analysis.confidence;
ticket.suggestedQuestions = response.clarifyingQuestions;
```

### With Slack
```javascript
// User sends message in #support channel
bot.on('message', async (message) => {
  const response = await generateResponse(message.text);
  
  // Post as thread reply
  bot.reply(message, {
    blocks: [
      { type: "section", text: { type: "mrkdwn", text: `*Suggested Response*\n${response.acknowledgment}` } },
      { type: "divider" },
      { type: "section", text: { type: "mrkdwn", text: `*Questions to Ask*\n${response.clarifyingQuestions.join('\n')}` } }
    ]
  });
});
```

### With Custom CRM
```python
# Python integration example
from anthropic import Anthropic

client = Anthropic()

def generate_support_response(enquiry_text):
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1000,
        messages=[{
            "role": "user",
            "content": f"[SYSTEM PROMPT HERE]\n\nCustomer enquiry: {enquiry_text}"
        }]
    )
    
    return json.loads(response.content[0].text)

# Usage
enquiry = "My internet keeps disconnecting"
result = generate_support_response(enquiry)
print(f"Confidence: {result['analysis']['confidence']}")
print(f"Recommended questions: {result['clarifyingQuestions']}")
```

---

## Best Practices

### ✅ DO:
- Review all responses before sending (100% for first month)
- Pay special attention to confidence < 0.8
- Check warnings section for legal/safety issues
- Use clarifying questions to gather context
- Include warnings in customer communications
- Track which responses customers found helpful
- Update system prompt with company-specific context

### ❌ DON'T:
- Send responses without human review
- Make promises on behalf of company
- Use for legal advice without lawyer review
- Rely on system for product pricing/inventory
- Share customer conversations with model (privacy)
- Ignore low confidence scores
- Remove warnings before sending

---

## Troubleshooting

### "Error: Invalid response format from API"
- Check internet connection
- Verify API is accessible
- Try again (rate limiting)
- Check browser console for details

### Response seems generic/unhelpful
- Confidence too low? Requires manual crafting
- Missing context? Add more details to enquiry
- Confidence still low after details? Route to specialist
- Try regenerating with slightly different wording

### Hallucinations detected
- Example: "We offer 30-day returns" (not true)
- Solution: Add company policies to system prompt
- Solution: Increase review intensity for this domain
- Solution: Create specialized sub-prompts for product issues

### Excessive warnings
- Some domains (legal, medical) inherently uncertain
- This is correct behavior (safety first)
- Either: Get expert input, or
- Accept that specialist routing is needed

---

## Metrics to Track

### System Health
- % of responses approved by humans (target: > 85%)
- Average confidence score (target: > 0.75)
- % with confidence < 0.6 (investigate/improve)
- Average review time (should decrease with use)

### Business Impact
- Customer satisfaction with suggested responses
- % of responses sent without modification
- Reduction in escalations
- Time saved per response (vs. manual drafting)

### Quality Indicators
- False claims detected in review (should → 0)
- Customers confused by response (feedback)
- Helpful clarifying questions (customer feedback)
- Needed specialist escalation (route correctly)

---

## Support & Feedback

For issues or improvements:
1. Check SYSTEM_DOCUMENTATION.md for technical details
2. Review examples in this README
3. Test with provided example enquiries
4. Track quality metrics as you use the system
5. Collect user feedback for future improvements

---

## License & Attribution

Built with Claude Sonnet 4 API
Requires Anthropic API access
For commercial use, review Anthropic's terms of service
